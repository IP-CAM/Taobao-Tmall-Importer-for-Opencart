<?php
class ControllerCedTaobaoImporterColumnLeft extends Controller {
    public function eventMenu($route, &$data)
    {
        $this->load->language('extension/module/ced_taobao_importer');

        $this->load->library('cedtaobaoimporter');
        $cedtaobaoimporter = Cedtaobaoimporter::getInstance($this->registry);

        // taobao menues
        $ced_taobao_menu=array();

        // taobao Product
        if ($this->user->hasPermission('access', 'ced_taobao_importer/product'))
        {
            $ced_taobao_menu[] = array(
                'name'     => $this->language->get('text_product'),
                'href'     => $this->url->link('ced_taobao_importer/product', 'user_token=' . $this->session->data['user_token'], true),
                'children' => array()
            );

        }

        // taobao Configuration
        $ced_taobao_menu[] = array(
            'name'     => $this->language->get('text_configuration'),
            'href'     => $this->url->link('extension/module/ced_taobao_importer', 'user_token=' . $this->session->data['user_token'], true),
            'children' => array()
        );

        $data['menus'][] = array(
            'id'       => 'menu-taobao',
            'icon'     => 'fa-rocket',
            'name'     => $this->language->get('text_ced_taobao'),
            'href'     => '',
            'children' => $ced_taobao_menu
        );

    }
}
