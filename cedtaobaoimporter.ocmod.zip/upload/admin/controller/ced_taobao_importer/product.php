<?php

class ControllerCedTaobaoImporterProduct extends Controller
{
    private $error = array();

    public function index()
    {
        $data = $this->load->language('ced_taobao_importer/product');
        //$this->load->model('ced_taobao_importer/setting');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['heading_title'] = $this->language->get('heading_title');
        //entry
        $data['entry_url'] = $this->language->get('entry_url');

        //text
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_enabled'] = $this->language->get('text_enabled');

        //buttons texts
        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['button_import'] = $this->language->get('button_import');

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('extension/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/ced_taobao_importer_product', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['action'] = $this->url->link('extension/module/ced_taobao_importer', 'user_token=' . $this->session->data['user_token'], 'SSL');

        $data['user_token'] = $this->session->data['user_token'];

        $opc_error = array(
            'warning',
            'filter'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->session->data[$value])) {
                $data['error_' . $value] = $this->session->data[$value];
            } else {
                $data['error_' . $value] = '';
            }
        }

        // Categories
        $this->load->model('catalog/category');

        $categories = $this->model_catalog_category->getCategories();

        if(isset($categories) && !empty($categories))
        {
            $data['product_categories'] = $categories;
        } else {
            $data['product_categories'] = array();
        }

        // Manufacturer
        $this->load->model('catalog/manufacturer');

        $manufacturer = $this->model_catalog_manufacturer->getManufacturers();

        if(isset($manufacturer) && !empty($manufacturer))
            $data['product_manufacturer'] = $manufacturer;
        else
            $data['product_manufacturer'] = array();

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('ced_taobao_importer/product_import', $data));
    }

    public function singleProductImport()
    {
        $post_data = $this->request->post;

        $category_id = isset($post_data['category_id']) ? $post_data['category_id'] : '';
        $manufacturer_id = isset($post_data['manufacturer_id']) ? $post_data['manufacturer_id'] : '';

        if(isset($post_data['product_url']) && (strpos($post_data['product_url'],'http') !== false))
        {
            $u=parse_url(urldecode($post_data['product_url']));
            @parse_str($u['query'], $var);

            if(isset($var['item_id']) && !empty($var['item_id']))
                @$hhid = $var['item_id'];
            elseif(isset($var['id']) && !empty($var['id']))
                @$hhid = $var['id'];

            if(strpos($post_data['product_url'],'world')){
                preg_match_all('/com\/item\/(\d+).htm/',$post_data['product_url'],$b);
                $hhid = $b[1][0];
            }
            if((strpos($post_data['product_url'],'tmall') !== false) || (strpos($post_data['product_url'],'ju.taobao.com') !== false))
            {
                $post_data['product_url'] = 'https://detail.tmall.com/item.htm?id=' . $hhid;
            } else {
                $post_data['product_url'] = 'https://item.taobao.com/item.htm?id=' . $hhid;
            }
        }

        unset($post_data['category_id']);
        unset($post_data['manufacturer_id']);

        $response['success'] = false;
        $response['message'] = 'Product not imported';

        try {
            $this->load->model('setting/setting');
            $cedtaobaoConfigData = $this->model_setting_setting->getSetting('ced_taobao_importer');
            $this->load->library('cedtaobaoimporter');
            $cedtaobaoimporter = Cedtaobaoimporter::getInstance($this->registry);

            $filters = $cedtaobaoimporter->prepareFilters($post_data);
            $productData = $cedtaobaoimporter->getProductData($filters);

            if (isset($productData['Result']
                    ['Items']['Items']['Content']['Item']) && !empty($productData['Result']
                ['Items']['Items']['Content']['Item']))
            {
                $productDatum = $productData['Result']['Items']['Items']['Content']['Item'];
                $response = $cedtaobaoimporter->prepareProductData($cedtaobaoConfigData, $productDatum, $category_id, $manufacturer_id);
            }
        } catch (\Exception $exception) {
            $response['success'] = false;
            $response['message'] = $exception->getMessage();
        }
        $this->response->setOutput(json_encode($response));
    }

    public function bulkProductImport()
    {
        $get_data = $this->request->get;

        $category_id = isset($get_data['category_id']) ? $get_data['category_id'] : '0';
        $manufacturer_id = isset($get_data['manufacturer_id']) ? $get_data['manufacturer_id'] : '0';
        $get_data['product_url'] = isset($get_data['keyword']) ? $get_data['keyword'] : '';

        unset($get_data['category_id']);
        unset($get_data['manufacturer_id']);
        unset($get_data['keyword']);

        $response['success'] = false;
        $response['message'] = 'Product not imported';
        try {
            $this->load->library('cedtaobaoimporter');
            $cedtaobaoimporter = Cedtaobaoimporter::getInstance($this->registry);

            $params['framePosition'] = 0; // offset
            $params['frameSize'] = 100; // limit

            $filters = $cedtaobaoimporter->prepareFilters($get_data);
            $productData = $cedtaobaoimporter->getProductData($filters, $params);
            $data['total'] = 0;

            if(isset($productData['Result']['Items']['Items']['TotalCount']) && !empty($productData['Result']['Items']['Items']['TotalCount']))
            {
                $total = (int) ($productData['Result']['Items']['Items']['TotalCount'] / 10);
                $data['total'] = ceil($total);
                $data['framePosition'] = '0';
            }

//            $data = $this->load->language('ced_taobao_importer/product');
            $this->document->setTitle('Import All Product(s)');
            $data['heading_title'] = 'Import All Product(s)';

            $data['product_url'] = $get_data['product_url'];
            $data['vendor'] = isset($get_data['vendor']) ? $get_data['vendor'] : '';
            $data['category_id_taobao'] = isset($get_data['category_id_taobao']) ? $get_data['category_id_taobao'] : '';
            $data['category_id'] = $category_id;
            $data['manufacturer_id'] = $manufacturer_id;

            $data['loaderImage'] = HTTP_SERVER . 'view/image/ced_taobao_importer/loader.gif';
            $data['successImage'] = HTTP_SERVER . 'view/image/ced_taobao_importer/uploaded.png';
            $data['errorImage'] = HTTP_SERVER . 'view/image/ced_taobao_importer/notuploaded.jpg';

            $data['ajaxUrl'] = 'index.php?route=ced_taobao_importer/product/importallProcess&user_token=' . $this->session->data['user_token'];

            $data['breadcrumbs'] = array();

            $data['breadcrumbs'][] = array(
                'text'      => $this->language->get('text_home'),
                'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], 'SSL'),
            );

            $data['breadcrumbs'][] = array(
                'text'      => 'Import All Product(s)',
                'href'      => $this->url->link('ced_taobao_importer/product/bulkProductImport', 'user_token=' . $this->session->data['user_token'], 'SSL'),
            );

            if (isset($this->session->data['warning'])) {
                $data['error_warning'] = $this->session->data['warning'];
                unset($this->session->data['warning']);
            } else {
                $data['error_warning'] = '';
            }

            if (isset($this->session->data['success'])) {
                $data['success'] = $this->session->data['success'];
                unset($this->session->data['success']);
            } else {
                $data['success'] = '';
            }

            $data['cancel'] = $this->url->link('ced_taobao_importer/product', 'user_token=' . $this->session->data['user_token'] , true);

        } catch (\Exception $exception) {
            $response['success'] = false;
            $response['message'] = $exception->getMessage();
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('ced_taobao_importer/importall', $data));
    }

    public function importallProcess()
    {
        $this->load->library('cedtaobaoimporter');
        $this->load->language('extension/module/ced_taobao_importer/product');
        $this->document->setTitle('Import All Product(s)');

        $product_chunk_data = $this->request->get;

        if((isset($product_chunk_data['product_url']) && $product_chunk_data['product_url']
                || isset($product_chunk_data['vendor']) && $product_chunk_data['vendor']
                || isset($product_chunk_data['category_id_taobao']) && $product_chunk_data['category_id_taobao'])
            && isset($product_chunk_data['page']) && $product_chunk_data['page'])
        {
            if(!empty($product_chunk_data['category_id'])) {
                $category_id = $product_chunk_data['category_id'];
            } else {
                $category_id = '';
            }

            if(!empty($product_chunk_data['manufacturer_id'])) {
                $manufacturer_id = $product_chunk_data['manufacturer_id'];
            } else {
                $manufacturer_id = '';
            }

            $this->load->model('setting/setting');
            $cedtaobaoConfigData = $this->model_setting_setting->getSetting('ced_taobao_importer');
            $params['framePosition'] = $product_chunk_data['framePosition']; // offset
            $params['frameSize'] = '10'; // limit
            $cedtaobaoimporter = CedtaobaoImporter::getInstance($this->registry);
            $filters = $cedtaobaoimporter->prepareFilters($product_chunk_data);
            $productData = $cedtaobaoimporter->getProductData($filters, $params);

            if (isset($productData['Result']['Items']['Items']['Content']['Item']) && !empty($productData['Result']['Items']['Items']['Content']['Item'])) {
                $json = array();
                $error_message = array();
                $success_message = array();
                foreach ($productData['Result']['Items']['Items']['Content']['Item'] as $productDatum)
                {
                    if (isset($productDatum['HasError']) && $productDatum['HasError'] == 'true') {
                        continue;
                    }
                    $response = $cedtaobaoimporter->prepareProductData($cedtaobaoConfigData, $productDatum, $category_id, $manufacturer_id);
                    $message = explode('- ', $response['message']);

                    if(isset($response['success']) && $response['success'] == true)
                    {
                        $success_message[] = @$message[0];
                    } else {
                        $error_message[] = @$message[0];
                    }
                }
            }

            if(!empty($error_message) && !empty($success_message)) {
                $json["success"] = true;
                $json["message"] = 'Product ID(s) - ' . implode(',', $success_message) . ' imported successfully and Product ID(s) - ' . implode(',', $error_message) . ' already imported';
            } elseif(!empty($error_message)) {
                $json["success"] = false;
                $json["message"] = 'Product ID(s) - ' . implode(',', $error_message) . ' already imported';
            } elseif(!empty($success_message)) {
                $json["success"] = true;
                $json["message"] = 'Product ID(s) - ' . implode(',', $success_message) . ' imported successfully';
            } else {
                $json["success"] = false;
                $json["message"] = 'Product ID(s) - Error while importing product';
            }
        } else {
            $json["success"] = false;
            $json["message"] = 'Product not imported';
        }

        //$this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
}