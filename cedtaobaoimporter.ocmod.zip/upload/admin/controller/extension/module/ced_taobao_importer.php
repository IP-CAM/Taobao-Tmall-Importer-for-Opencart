<?php class ControllerExtensionModuleCedTaobaoImporter extends Controller
{
    private $error = array();

    public function index()
    {
        $data = $this->load->language('extension/module/ced_taobao_importer');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');
        /*save settings*/

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate())
        {
            $this->model_setting_setting->editSetting('ced_taobao_importer', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->cache->delete('ced_taobao_importer');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }

        $getConfigData = $this->model_setting_setting->getSetting('ced_taobao_importer');

        foreach($getConfigData as $key => $configData){
            $data[$key] = $configData;
            if($key == 'ced_taobao_importer_field_mapping'){
                foreach($configData as $index => $value){
                    $data['ced_taobao_importer_field_mapping_'.$index] = $value;
                }
            }
        }
        unset($data['ced_taobao_importer_field_mapping']);

        $data['heading_title'] = $this->language->get('heading_title');
        $data['ced_taobao_importer_key'] = html_entity_decode($this->config->get('ced_taobao_importer_key'));

        //breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL')
        );

        $data['action'] = $this->url->link('extension/module/ced_taobao_importer', 'user_token=' . $this->session->data['user_token'], 'SSL');

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', 'SSL');
        $data['user_token'] = $this->session->data['user_token'];
        $ced_taobao_importer_config = array(
            'status',
            'ot_key',
            'language',
            //'provider',
            //'category',
            //'vendor',
            'google_api_key',
            'default_store',
            'tax_class_id',
            'available_date',
            'weight_class_id',
            'length_class_id',
            'product_store',
            'access_token',
            'expires_in',
            'refresh_token',
            'refresh_expires_in',
            'country'
        );

        $this->load->model('setting/store');

        $data['default_stores'] = $this->model_setting_store->getStores();

        $this->load->model('localisation/language');
        $data['languages'] = $this->model_localisation_language->getLanguages();

        foreach ($ced_taobao_importer_config as $value) {
            if (isset($this->request->post['ced_taobao_importer_'.$value])) {
                $data['ced_taobao_importer_'.$value] = $this->request->post['ced_taobao_importer_'.$value];
            } else {
                if($value=='product_store')
                    $data['ced_taobao_importer_'.$value] = array(0);
                else if($value=='status')
                    $data['ced_taobao_importer_'.$value] = (int)1;
                else if($this->config->get('ced_taobao_importer_'.$value))
                    $data['ced_taobao_importer_'.$value] = $this->config->get('ced_taobao_importer_'.$value);
                else
                    $data['ced_taobao_importer_'.$value] = '';
            }
        }

        $opc_error = array(
            'warning',
            'ot_key',
            'tax_class_id',
            'date_available',
            'weight_class_id',
            'length_class_id',
            'product_store',
            'available_date'
        );

        foreach ($opc_error as $key => $value) {
            if (isset($this->error[$value])) {
                $data['error_'.$value] = $this->error[$value];
            } else {
                $data['error_'.$value] = '';
            }
        }

        $this->load->model('localisation/tax_class');

        $data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();

        $this->load->model('localisation/weight_class');

        $data['weight_classes'] = $this->model_localisation_weight_class->getWeightClasses();

        $this->load->model('localisation/length_class');

        $data['length_classes'] = $this->model_localisation_length_class->getLengthClasses();

        $this->load->model('setting/store');

        // Categories
        $this->load->model('catalog/category');

        if (isset($this->request->post['product_category'])) {
            $categories = $this->request->post['product_category'];
        } elseif (isset($this->request->get['product_id'])) {
            $categories = $this->model_catalog_product->getProductCategories($this->request->get['product_id']);
        } elseif($this->config->get('ced_taobao_importer_product_category')){
            $categories = $this->config->get('ced_taobao_importer_product_category');
        }  else {
            $categories = array();
        }

        $data['product_categories'] = array();

        foreach ($categories as $category_id) {
            $category_info = $this->model_catalog_category->getCategory($category_id);

            if ($category_info) {
                $data['product_categories'][] = array(
                    'category_id' => $category_info['category_id'],
                    'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
                );
            }
        }

        $product_fields = array();
        try{
            $colomns = $this->db->query("SHOW COLUMNS FROM `".DB_PREFIX."product`;");
            if($colomns->num_rows) {
                $product_fields = $colomns->rows;
            }
            $this->array_sort_by_column($product_fields, 'Field');

            $product_fields[] =  array(
                'Field' => 'currency_id',
                'Type' => 'int',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'customer_group_id',
                'Type' => 'int',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'description',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'name',
                'Type' => 'text',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '',
                'Extra' =>'',
            );
            $product_fields[] =  array(
                'Field' => 'special_price',
                'Type' => 'float',
                'Null' => 'NO',
                'Key' =>'' ,
                'Default' => '0',
                'Extra' =>'',
            );

        }catch(Exception $e){
            echo $e->getMessage();die;
        }

        $data['stores'] = $this->model_setting_store->getStores();

        $data['product_fields'] = $product_fields;
        $ced_taobao_product_fields = array(
            'name',
            'description',
            'price',
            'special_price',
            'quantity',
            'Sku',
            'Status',
            'product_weight',
            'package_weight',
            'package_width',
            'package_height',
            'package_length',
            'customer_group',
            'currency_id'
        );
        $data['ced_taobao_product_fields'] = $ced_taobao_product_fields;

//        echo '<pre>'; print_r($this->config->get('ced_taobao_importer_field_mapping')); die;

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/module/ced_taobao_importer', $data));
    }

    public function array_sort_by_column(&$arr, $col, $dir = SORT_ASC) {
        $sort_col = array();
        foreach ($arr as $key=> $row) {
            $sort_col[$key] = $row[$col];
        }

        array_multisort($sort_col, $dir, $arr);
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'extension/module/ced_taobao_importer')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }

    public function install() {
        $this->load->language('extension/module/ced_taobao_importer');

        $this->load->model('setting/event');
        $this->model_setting_event->addEvent('add_taobao_menu', 'admin/view/common/column_left/before', 'ced_taobao_importer/column_left/eventMenu');

        $this->load->model('user/user_group');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_taobao_importer/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_taobao_importer/product');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/ced_taobao_importer');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/ced_taobao_importer');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_taobao_importer/column_left');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_taobao_importer/column_left');

        $this->load->library('cedtaobaoimporter');
        $Importertaobao = Cedtaobaoimporter::getInstance($this->registry);
        $isInstalled = $Importertaobao->isInstalled();
        if(!$isInstalled) {
            $Importertaobao->install();
        }
    }

    public function uninstall() {
        //$this->load->model('setting/setting');
        //$this->model_setting_setting->deleteSetting($this->request->get['extension']);
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('add_taobao_menu');
    }

    public function validateotkey()
    {
        $this->load->model('setting/setting');
        $this->load->language('extension/module/ced_taobao_importer');
        $this->model_setting_setting->editSetting('ced_taobao_importer', $this->request->post);
        $this->load->library('cedtaobaoimporter');
        $cedtaobaoimporter = Cedtaobaoimporter::getInstance($this->registry);
        $response = $cedtaobaoimporter->validateOTKey();
        $this->response->setOutput(json_encode($response));
    }
}

?>
